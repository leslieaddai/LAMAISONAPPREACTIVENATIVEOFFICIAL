export default {
  Login: 'Login',
  Logout: 'Logout',
  HideSplash: 'HideSplash',
  ShowSplash: 'ShowSplash',
  HideWelcome: 'HideWelcome',
  ShowWelcome: 'ShowWelcome',
  AddToBasket: 'AddToBasket',
  RemoveFromBasket: 'RemoveFromBasket',
};
