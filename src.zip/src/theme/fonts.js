const fonts = {
    PoppinsRegular: "Poppins-Regular",
    PoppinsMedium: "Poppins-Medium",
    PoppinsBold: "Poppins-Bold",

    MontserratRegular: "Montserrat-Regular",
    MontserratMedium: "Montserrat-Medium",
    MontserratBold: "Montserrat-Bold",

    // AleoBold: "Aleo-Bold",
    // AleoMedium: "Aleo-Medium",
    // AleoRegular: "Aleo-Regular",

    OpenSansBold: "OpenSans-Bold",
    OpenSansMedium: "OpenSans-Regular",
    OpenSansRegular: "OpenSans-Regular",

    // AmostelySignature: "AmostelySignature",
    // MrDeHavilandRegular: "MrDeHaviland-Regular"
}
export default fonts